Hey my friends!

Welcome to Catan Online! You will need three other friends with you! If you want to get a basic outline on how Catan works, you can visit their website:
https://www.catan.com/game/catan#prof-easy

Whenever you guys are ready, one of you guys needs to boot up the server.py! (if you are having issues, make sure to open up the file and check the port number (line 9)!) If you are playing using four different computers, make sure to put your IP address in the appropriate line (line 8)!

Once the server is booted up, every player needs to run client.py. The only libraries needed that are Tkinter, sockets, threading, queues, and more built in libraries, so you should be good to go from the start!

Make sure to go into the client.py file and fill in the same port number as the server on line 10 and the same HOST IP address on line 9.

Once all four of you guys are logged in. Player 1 (red) can press start and that brings you guys into the set up phase of catan! Once each player has placed their first two settlements, player 1 can start rolling and playing the game! First to 10 points win, and good luck!